'use client';


export default function Reports() {
  return <div>Reports Page</div>
}