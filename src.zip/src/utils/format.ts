// src/utils/format.ts
import { StationWithDetails, ProprietairePhysique, ProprietaireMorale } from '@/types/station';

export function formatDate(value: any): string {
  if (!value) return 'N/A';
  if (value instanceof Date) {
    // Format as DD/MM/YYYY
    return value.toLocaleDateString('fr-FR');
  }
  // Handle Firestore Timestamps
  if (typeof value.toDate === 'function') {
    return value.toDate().toLocaleDateString('fr-FR');
  }
  return String(value);
}

/**
 * 5. FIX: Safely gets the full name of a station's owner.
 * This function is now more robust. The "N/A" issue likely stems from Firestore data
 * where a 'proprietaires' entry exists without its corresponding details in
 * 'proprietaires_physiques' or 'proprietaires_morales'.
 */
export function getProprietaireName(station: StationWithDetails): string {
  if (!station.proprietaire || !station.proprietaire.details) {
    return 'N/A';
  }
  
  const { details } = station.proprietaire;

  // Check if it's a ProprietairePhysique
  if ('PrenomProprietaire' in details && 'NomProprietaire' in details) {
    const physique = details as ProprietairePhysique;
    return `${physique.PrenomProprietaire || ''} ${physique.NomProprietaire || ''}`.trim() || 'N/A';
  }

  // Check if it's a ProprietaireMorale
  if ('NomEntreprise' in details) {
    const morale = details as ProprietaireMorale;
    return morale.NomEntreprise || 'N/A';
  }

  return 'N/A';
}